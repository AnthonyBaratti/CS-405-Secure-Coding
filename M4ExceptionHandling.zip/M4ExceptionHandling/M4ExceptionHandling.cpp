//////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Anthony Baratti
// SNHU CS-405 Secure Coding
// Professor R. Kraya
// March 30, 2025
// 
// M4ExceptionHandling.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Purpose of the application is to demonstrate exception handling
// through try/catch blocks and various exception handling
// methods.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <exception> //Used for custom exceptions
#include <string> //Used for custom string message

///////////////////////////////////////
// Create custom exception class
//
// REF:
// GeeksforGeeks. (2024). How to throw a custom exception in C++.
//      Geeksforgeeks.org. https://www.geeksforgeeks.org/how-to-throw-custom-exception-in-cpp/
//////////////////////////////////////

class CustomException : public std::exception {
private:
    std::string message;

public:
    //Constructor accepts a const char* that is used
    // to set the exception message
    CustomException(const char* msg) : message(msg) {

    }

    //override the what() method to return the message
    const char* what() const throw() {
        return message.c_str();
    }
};


bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    ////////////////////
    // Throw standard exception (logic_error)
    // REF:
    // Geeksforgeeks. (2022). C++ Program to handle the exception methods
    //      Geeksforgeeks.org. https://www.geeksforgeeks.org/cpp-program-to-handle-the-exception-methods/
    ////////////////////

    throw std::logic_error::logic_error("Logic error: throwing standard exception");
    
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    try { //wrap the call in try block
        std::cout << "Running Custom Application Logic." << std::endl;

        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) { 
        //catch the exception thrown by do_eve_more_custom_application_logic() 
        std::cout << "Catching standard exception -- " << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    //calls custom exception with a message as parameter
    throw CustomException("This is the custom exception");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
     
    
    /////////////////////
    // Checks the denominator for zero value
    //
    // REF:
    // GeeksforGeeks. (2024). Handling the divide by zero
    //      exception in C++. GeeksforGeeks.org.
    //      https://www.geeksforgeeks.org/handling-the-divide-by-zero-exception-in-c/
    ////////////////////
    
    if (den == 0) {
        throw std::runtime_error("Attempting to divide by zero");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    /////////////////////////////////////////
    // REF:
    // GeeksforGeeks. (2024). Handling the divide by zero
    //      exception in C++. GeeksforGeeks.org.
    //      https://www.geeksforgeeks.org/handling-the-divide-by-zero-exception-in-c/
    ////////////////////

    //try catch block that calls the division function.
    try { //Place function call and correct output in try block
        
        float numerator = 10.0f;
        float denominator = 0;
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::runtime_error& e) { //place division function error handling in catch block
        std::cout << "Exception occured -- " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    //wrap functions in try block
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) { //first catch, custom exception
        std::cout << e.what() << std::endl;
    }
    catch (const std::exception& e) { //second catch, standard exception
        std::cout << e.what() << std::endl;
    }
    catch (...) { //catch all
        std::cout << "Caught an exception" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu